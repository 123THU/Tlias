package com.itheima.utils;

import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;


class JwtUtilsTest {

    /**
     * 生成 jwt token
     */
    @Test
    void testGenCode() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", 1);
        map.put("username", "zhangsan");
        String jwt = JwtUtils.generateJwt(map);
        System.out.println(jwt);
    }

    /**
     * 解析 jwt token
     */
    @Test
    void testParCode() {
        Claims claims = JwtUtils.parseJWT("eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJ6aGFuZ3NhbiIsImV4cCI6MTczMzc4ODA3OX0.6W29pVA98mtDLjiVNncAFtBrKQPlan-LSZCIrKQ82Go");
        System.out.println(claims);
    }
}