package com.itheima.mapper;

import com.itheima.pojo.Dept;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * 部门管理
 */
@Mapper  //由Mybatis提供，表示当前接口是持久层
// 并且项目启动之后根据动态代理生成实现类，交给spring的ioc管理
public interface DeptMapper {

    @Select("select * from dept")
    List<Dept> findAll();

    /**
     * 添加部门信息
     * @param dept
     * @return
     */
    @Insert("INSERT INTO dept (name,create_time,update_time) VALUES(#{name},#{createTime},#{updateTime})")
    int save(Dept dept);

    @Delete("delete  from dept where id= #{id}")
    int deleteById(Integer id);

    @Select("SELECT * FROM dept WHERE id = #{id}")
    Dept getById(Integer id);

    @Update("update dept set name=#{name},update_time=#{updateTime} where id=#{id}")
    int update(Dept dept);
}
