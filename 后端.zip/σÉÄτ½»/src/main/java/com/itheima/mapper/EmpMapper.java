package com.itheima.mapper;

import com.github.pagehelper.Page;
import com.itheima.pojo.Emp;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.util.List;

/**
 * 员工管理
 */
@Mapper
public interface EmpMapper {
    /**
     * 查询当前部门有多少员工
     * @param id
     * @return
     */
    @Select("select count(*) from emp where dept_id=#{id}")
    int countByDeptId(Integer id);

    // @Param Mybatis提供的注解，为方法中的每一个参数，指定SQL语句中的名称
    Page<Emp> selectPage(@Param("name") String name,
                         @Param("gender") Short gender,
                         @Param("begin") LocalDate begin,
                         @Param("end") LocalDate end);


    @Insert("insert into emp(username,name,gender,image,job,entrydate,dept_id,create_time,update_time)" +
            " values (#{username},#{name},#{gender},#{image},#{job},#{entrydate},#{deptId},#{createTime},#{updateTime}) ")
    int save(Emp emp);

    /**
     * 根据id进行员工信息删除（动态sql的应用)
     * @param ids
     * @return
     */
    int delete(List<Integer> ids);

    @Select("select id, username, password, name, gender, image, job, entrydate, dept_id, create_time, update_time " +
            "from emp " +
            "where id = #{id}")
    Emp findById(Integer id);

    int update(Emp emp);

    @Select("select * from emp where username = #{username} and password = #{password}")
    Emp getByUsernameAndPassword(@Param("username") String username,
                                 @Param("password") String password);
}
