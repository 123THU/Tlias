package com.itheima.common;

public class ConstrainException extends RuntimeException {
    public ConstrainException(String message) {
        super(message);
    }

}
