package com.itheima.common;

import com.itheima.pojo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLIntegrityConstraintViolationException;

@ControllerAdvice(annotations = {RestController.class, Controller.class})
// 由spring提供，表明当前类是一个全局异常处理器
// annotations 属性 设置需要捕获异常的范围，默认是所有异常
// 里面写RestController.class Controller.class 表示加了这两个注解的类 出现了异常都会被捕获到
@ResponseBody  // 表示当前方法的返回值会转化成json格式
@Slf4j  // lombok提供日志注解log
public class GlobalExceptionHandler {
    /**
     * 捕获业务异常
     * @ExceptionHandler 表示当前方法可以处理捕获的异常
     */
    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    public Result exceptionHandler(SQLIntegrityConstraintViolationException ex){
        log.error("出现异常：{}", ex.getMessage());

        if (ex.getMessage().contains("Duplicate entry")){
            String[] split = ex.getMessage().split(" ");
            String msg=split[2]+"已存在";
            return Result.error(msg);
        }
        return Result.error("未知错误");
    }

    /**
     * 捕获运行时异常
     */
    @ExceptionHandler(ConstrainException.class)
    // 表示当前类可以捕获的异常类型为ConstrainException类
    public Result exceptionHandler(ConstrainException ex){
        log.error("出现异常：{}", ex.getMessage());
        return Result.error(ex.getMessage());
    }

}
