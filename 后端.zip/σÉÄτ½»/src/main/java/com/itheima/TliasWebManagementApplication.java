package com.itheima;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@Slf4j // lombok提供注解
public class TliasWebManagementApplication {
    /**
     * 启动项目
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        /**
         * 启动SpringBoot项目 需要调用SpringApplication类的run方法
         * 参数1 启动类的类名
         * 参数2 命令行参数
         */
        SpringApplication.run(TliasWebManagementApplication.class, args);
        log.info("项目启动成功");  // @Slf4j
    }

}
