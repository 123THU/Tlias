package com.itheima.utils;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

///**
// * 阿里云 OSS 工具类
// */
//@Component // 将当前组件注入到Spring容器中
//public class AliOSSUtils {
//    /**
//     * 用户登录名称 hd2@1349930181259166.onaliyun.com
//     * AccessKey ID LTAI5tQ6iMBZX6XV7SN8qKQL
//     * AccessKey Secret yUCM0vUeAzhoG5shVkvYJP2sOs8DxR
//     */
//    // 地域节点 存储空间的外网访问地址
//    private String endpoint = "https://oss-cn-beijing.aliyuncs.com";
//    // 阿里云账号的AccessKey拥有所有API的访问权限，风险很高
//    private String accessKeyId = "LTAI5tLfKZRwrcwE8G71giqB";
//    private String accessKeySecret = "F96zXctc3SlurHcZdyALN56zv7EJdQ";
//    // 存储空间名称
//    private String bucketName = "ivytlias";
//
//    /**
//     * 实现上传图片到OSS
//     */
//    public String upload(MultipartFile file) throws IOException {
//        // 获取上传的文件的输入流
//        InputStream inputStream = file.getInputStream();
//
//        // 避免文件覆盖  1.jpg
//        String originalFilename = file.getOriginalFilename();
//        String fileName = UUID.randomUUID().toString() + originalFilename.substring(originalFilename.lastIndexOf("."));
//
//        //上传文件到 OSS
//        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
//        ossClient.putObject(bucketName, fileName, inputStream);
//
//        //文件访问路径
//        //https://hd-tlias2.oss-cn-beijing.aliyuncs.com/0a3b3288-3446-4420-bbff-f263d0c02d8e.jpg
//        //https://oss-cn-beijing.aliyuncs.com
//        //https://hd-tlias2.oss-cn-beijing.aliyuncs.com/0a3b3288-3446-4420-bbff-f263d0c02d8e.jpg
//        String url = endpoint.split("//")[0] + "//" + bucketName + "." + endpoint.split("//")[1] + "/" + fileName;
//        // 关闭ossClient
//        ossClient.shutdown();
//        return url;// 把上传到oss的路径返回
//    }
//
//}
@Component
public class AliOSSUtils {

    private static final Logger logger = LoggerFactory.getLogger(AliOSSUtils.class);

    private String endpoint = "oss-cn-beijing.aliyuncs.com"; // 如：oss-cn-beijing.aliyuncs.com
    private String accessKeyId = "LTAI5tLfKZRwrcwE8G71giqB";
    private String accessKeySecret = "F96zXctc3SlurHcZdyALN56zv7EJdQ";
    private String bucketName = "ivytlias";

    /**
     * 实现上传图片到OSS
     */
    public String upload(MultipartFile file) {
        // 记录上传的文件名
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.isEmpty()) {
            logger.error("上传文件名为空");
            throw new IllegalArgumentException("文件名不能为空");
        }
        logger.info("开始上传文件: {}", originalFilename);

        // 生成唯一的文件名，避免文件名重复
        String fileName = UUID.randomUUID().toString() + originalFilename.substring(originalFilename.lastIndexOf("."));
        logger.info("生成唯一文件名: {}", fileName);

        // 创建OSSClient对象
        OSS ossClient = null;
        try {
            ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

            // 获取文件输入流
            InputStream inputStream = file.getInputStream();
            logger.info("文件上传准备就绪，开始上传");

            // 上传文件到OSS
            ossClient.putObject(bucketName, fileName, inputStream);

            // 构造文件访问路径
            String url = "https://" + bucketName + "." + endpoint.split("//")[1] + "/" + fileName;
            logger.info("文件访问路径: {}", url);

            return url; // 返回上传成功后的URL

        } catch (Exception e) {
            // 发生异常时输出日志
            logger.error("上传文件到OSS失败", e);
//            e.printStackTrace();
            throw new RuntimeException("上传文件到OSS失败：" + e.getMessage());
        } finally {
            // 关闭OSS客户端
            if (ossClient != null) {
                ossClient.shutdown();
                logger.info("OSS客户端已关闭");
            }
        }
    }
}
