package com.itheima.service;

import com.itheima.pojo.Dept;

import java.util.List;

/**
 * 部门管理
 */
public interface DeptService {
    List<Dept> list();

    Boolean save(Dept dept);

    // 删除部门
    Boolean deleteById(Integer id);

    Dept getById(Integer id);

    Boolean update(Dept dept);
}
