package com.itheima.service.impl;

import com.itheima.common.ConstrainException;
import com.itheima.mapper.DeptMapper;
import com.itheima.mapper.EmpMapper;
import com.itheima.pojo.Dept;
import com.itheima.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service // 这个注解由spring框架提供，表示当前类是业务逻辑层，并且交给spring的IoC容器管理
public class DeptServiceImpl implements DeptService {

    @Autowired  // 注入mapper
    private DeptMapper deptMapper;
    @Autowired
    private EmpMapper empMapper;

    @Override
    public List<Dept> list() {
        // 调用持久层mapper, 查询部门列表
        List<Dept> depts = deptMapper.findAll();
        return depts;
    }
    @Override
    public Boolean save(Dept dept) {
        // 1. 补全创建时间 修改时间字段
        dept.setCreateTime(LocalDateTime.now());
        dept.setUpdateTime(LocalDateTime.now());
        // 2. 调用mapper层进行添加
        int rows = deptMapper.save(dept);
        if (rows > 0) {
            return true;
        }
        return false;
    }
    @Override
    public Boolean deleteById(Integer id) {
        // 0. 先通过部门id，查看当前部门下是否存在员工，若不存在则可删除若存在则不可删除
        int count = empMapper.countByDeptId(id);
        if (count > 0) {
            throw new ConstrainException("当前部门有员工信息 不能删除部门");
        }

        // 1. 调用Mapper层进行删除
        int rows = deptMapper.deleteById(id);
        if (rows > 0) {
            return true;
        }
        return false;

    }
    @Override
    public Dept getById(Integer id) {
        return deptMapper.getById(id);
    }
    @Override
    public Boolean update(Dept dept) {
        // 补全修改时间
        dept.setUpdateTime(LocalDateTime.now());
        int rows = deptMapper.update(dept);
        if (rows > 0) {
            return true;
        }
        return false;
    }
}
