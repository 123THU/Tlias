package com.itheima.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.EmpMapper;
import com.itheima.pojo.Emp;
import com.itheima.pojo.PageBean;
import com.itheima.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class EmpServiceImpl implements EmpService {
    @Autowired
    private EmpMapper empMapper;

    @Override
    public PageBean page(Integer page, Integer pageSize, String name, Short gender, LocalDate begin, LocalDate end) {
        //1. 设置分页参数
        PageHelper.startPage(page, pageSize);

        //2. 查询数据列表 select * from emp
        Page<Emp> empPage = empMapper.selectPage(name, gender, begin, end);

        //3. 封装返回
        return new PageBean(empPage.getTotal(), empPage.getResult());
    }

    @Override
    public Boolean save(Emp emp) {
        // 1. 补全员工信息
        emp.setCreateTime(LocalDateTime.now());
        emp.setUpdateTime(LocalDateTime.now());
        // 2. 调用mapper层进行添加员工
        int rows = empMapper.save(emp);
        if (rows > 0) {
            return true;
        }
        return false;
    }

    @Override
    public Boolean delete(List<Integer> ids) {
        int rows = empMapper.delete(ids);
        if (rows > 0) {
            return true;
        }
        return false;

    }

    @Override
    public Emp getById(Integer id) {
        Emp emp = empMapper.findById(id);
        return emp;
    }

    @Override
    public Boolean update(Emp emp) {
        // 1. 补全修改信息
        emp.setUpdateTime(LocalDateTime.now());
        // 2. 调用mapper层进行信息修改
        int rows = empMapper.update(emp);
        if (rows > 0) {
            return true;
        }
        return false;
    }

    @Override
    public Emp getByUsernameAndPassword(String username, String password) {
        return empMapper.getByUsernameAndPassword(username, password);
    }
}
