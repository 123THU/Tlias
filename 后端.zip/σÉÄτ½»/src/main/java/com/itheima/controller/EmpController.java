package com.itheima.controller;

import com.itheima.pojo.Emp;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Result;
import com.itheima.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 员工管理Controller
 */
@RestController
@RequestMapping("/emps")
public class EmpController {

    @Autowired
    private EmpService empService;

    @GetMapping
    public Result page(
            String name,
            Short gender,
            @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate begin,
            @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate end,
            Integer page,
            Integer pageSize) {
        // 调用service 进行分页查询
        PageBean pageBean = empService.page(page, pageSize, name, gender, begin, end);
        return Result.success(pageBean);

    }

    /**
     * @RequstBody 将请求体中的json格式数据封装到Java对象中
     * @param emp
     * @return
     */
    @PostMapping
    public Result save(@RequestBody Emp emp) {
        // 1. 调用业务逻辑层进行员工添加
        Boolean flag = empService.save(emp);
        // 2. 返回结果
        if (flag) {
            return Result.success();
        }
        return Result.error("添加员工失败");

    }

    /**
     * 根据id进行员工信息删除
     * @PathVariable 是RESTful编码风格，注解由springBoot提供(springBoot支持RESTful风格)
     * ，含义为将url中的占位符ids绑定到形参ids中
     * 而RESTFul编码风格是远程过程调用的基于HTTP方式访问服务的一种具体实现，除此之外还有restTemplate风格，
     * 而远程过程调用除了基于HTTP方式访问服务之外，还有基于RPC的服务调用方式，最常见的是gRPC
     * @param ids
     * @return
     */
    @DeleteMapping("/{ids}")
    public Result delete(@PathVariable("ids") List<Integer> ids) {
        // 1. 调用业务逻辑层进行员工删除
        Boolean flag = empService.delete(ids);
        // 2. 返回结果
        if (flag) {
            return Result.success();
        }
        return Result.error("删除员工失败");
    }

    /**
     * 根据员工ID进行信息查询
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Result getById(@PathVariable("id") Integer id) {
        Emp emp = empService.getById(id);
        return Result.success(emp);
    }

    @PutMapping
    public Result update(@RequestBody Emp emp) {
        // 1. 调用业务逻辑层进行员工信息修改
        Boolean flag = empService.update(emp);
        if (flag) {
            return Result.success("修改员工信息成功");
        }
        return Result.error("修改员工信息失败");

    }

}
