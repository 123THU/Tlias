package com.itheima.controller;

import com.itheima.pojo.Dept;
import com.itheima.pojo.Result;
import com.itheima.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 部门管理Controller
 * RESTful编码风格
 * get
 * put 修改
 * post 添加
 * delete 删除
 */
@RestController // 由spring ioc容器管理，加在类上，表示类的所有方法返回值为json格式
// = @Controller + @ResponseBody
// @Controller表示是一个控制器，并且交给spring的IoC容器管理
// @ResponseBody表示当前方法的返回值为json格式
@RequestMapping("/depts")
public class DeptController {
    @Autowired // 依赖注入 根据接口名从spring的ioc容器中获取对应的实现类对象
    private DeptService deptService;

    @GetMapping
    public Result list() {
        // 调用服务层方法进行查询
        List<Dept> depts = deptService.list();
        return Result.success(depts);
    }

    /**
     * 新增部门
     * @RequestBody 将请求体中的json格式数据封装到dept对象中
     * @param dept
     * @return
     */
    @PostMapping
    public Result save(@RequestBody Dept dept) {
        // 1. 调用业务逻辑层进行部门添加
        boolean flag = deptService.save(dept);
        // 2. 返回结果
        if (flag) {
            return Result.success();
        }
        return Result.error("添加部门失败");
    }

    /**
     * 根据id删除部门
     * @PathVariable 获取路径参数，必须和占位符名称一致
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public Result deleteById(@PathVariable("id") Integer id) {
        // 1. 调用业务逻辑层进行删除操作
        Boolean flag = deptService.deleteById(id);
        // 2. 返回删除结果
        if (flag) {
            return Result.success();
        }
        return Result.error("删除部门失败");

    }
    @GetMapping("/{id}")
    public Result getById(@PathVariable("id") Integer id) {
        // 使用serivce 查询部门
        Dept dept = deptService.getById(id);
        // 响应部门数据
        return Result.success(dept);

    }

    @PutMapping
    public Result update(@RequestBody Dept dept) {
        // 1. 调用业务逻辑层进行部门修改
        Boolean flag = deptService.update(dept);
        if (flag) {
            return Result.success("修改部门成功");
        }
        return Result.error("修改部门失败");
    }

}

